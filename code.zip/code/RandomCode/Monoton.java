import java.util.Scanner;

public class Monoton {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Zahleneingabe");

        int previousNumber = Integer.MIN_VALUE;
        char result = 'S';
        boolean firstNumber = true;
        boolean isMonotonic = true;

        while (scanner.hasNextInt()) {
            int currentNumber = scanner.nextInt();

            if (firstNumber) {
                if (currentNumber < previousNumber) {
                    isMonotonic = false;
                    break;
                } else if (currentNumber == previousNumber) {
                    result = 'M';
                }
            } else {
                firstNumber = false;
            }

            previousNumber = currentNumber;
        }

        if (isMonotonic) {
        } else {
            result = 'N';
        }


        System.out.println(result);
    }
}
