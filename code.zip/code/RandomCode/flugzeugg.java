abstract class Flugzeug {
    private String hersteller;
    private int maxSpeed;
    private String luftfahrzeugkennzeichen;
    private int anzahlFluegelpaare = 1;

    public Flugzeug(String hersteller, int maxSpeed, int anzahlFluegelpaare) {
        this.hersteller = hersteller;
        this.maxSpeed = maxSpeed;
        this.anzahlFluegelpaare = anzahlFluegelpaare;
    }

    public String getLuftfahrzeugkennzeichen() {
        return luftfahrzeugkennzeichen;
    }

    protected void setLuftfahrzeugkennzeichen(String luftfahrzeugkennzeichen) {
        this.luftfahrzeugkennzeichen = luftfahrzeugkennzeichen;
    }

    public int getMaxSpeed() {
        return maxSpeed;
    }

    abstract public boolean getLooping();
}

class Verkehrsflugzeug extends Flugzeug {
    private int anzahlPassagiere;

    public Verkehrsflugzeug(String hersteller, int maxSpeed, String luftfahrzeugkennzeichen, int anzahlPassagiere) {
        super(hersteller, maxSpeed, 1);
        setLuftfahrzeugkennzeichen(luftfahrzeugkennzeichen);
        this.anzahlPassagiere = anzahlPassagiere;
    }

    public int getAnzahlPassagiere() {
        return anzahlPassagiere;
    }

    public void setAnzahlPassagiere(int anzahlPassagiere) {
        this.anzahlPassagiere = anzahlPassagiere;
    }

    public boolean getLooping() {
        return false;
    }
}

class Doppeldecker extends Flugzeug {
    private static final int LOOPINGSPEED = 319;
    private boolean offenesCockpit;

    public Doppeldecker(String hersteller, int maxSpeed, String luftfahrzeugkennzeichen, boolean offenesCockpit) {
        super(hersteller, maxSpeed, 2);
        setLuftfahrzeugkennzeichen(luftfahrzeugkennzeichen);
        this.offenesCockpit = offenesCockpit;
    }

    public Doppeldecker(String hersteller, int maxSpeed, String luftfahrzeugkennzeichen) {
        this(hersteller, maxSpeed, luftfahrzeugkennzeichen, true);
    }

    public boolean isOffenesCockpit() {
        return offenesCockpit;
    }

    public boolean getLooping() {
        return getMaxSpeed() > LOOPINGSPEED;
    }
}

public class flugzeugg {
    public static void main(String[] args) {
        Verkehrsflugzeug vf = new Verkehrsflugzeug("Boeing", 900, "ABC123", 200);
        System.out.println("Verkehrsflugzeug:");
        System.out.println("Hersteller: Lufthansa");
        System.out.println("Maximale Geschwindigkeit: " + vf.getMaxSpeed());
        System.out.println("Luftfahrzeugkennzeichen: " + vf.getLuftfahrzeugkennzeichen());
        System.out.println("Anzahl Passagiere: " + vf.getAnzahlPassagiere());
        System.out.println("Looping: " + vf.getLooping());

        Doppeldecker dd = new Doppeldecker("Red Baron", 300, "DEF456");
        System.out.println("\nDoppeldecker:");
        System.out.println("Hersteller: Boing");
        System.out.println("Maximale Geschwindigkeit: " + dd.getMaxSpeed());
        System.out.println("Luftfahrzeugkennzeichen: " + dd.getLuftfahrzeugkennzeichen());
        System.out.println("Offenes Cockpit: " + dd.isOffenesCockpit());
        System.out.println("Looping: " + dd.getLooping());
    }
}


