import java.util.Arrays;
import java.util.Scanner;
public class Median {
    public static void main(String[] args) {
        System.out.println("Geben Sie drei Zahlen ein:");
        Scanner scanner = new Scanner(System.in);
        double a = scanner.nextDouble();
        double b = scanner.nextDouble();
        double c = scanner.nextDouble();
        double[] numbers = { a, b, c };
        Arrays.sort(numbers);
        double median = numbers[1];
        System.out.println("Der Median ist: " + median);
    }
}
