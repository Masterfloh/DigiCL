import java.util.ArrayList;
import java.util.List;

class Auto {
    private String hersteller;
    private String antriebsart;
    private int motorleistung;
    private String farbe;
    private String sonderausstattung;

    public Auto(String hersteller, String antriebsart, int motorleistung, String farbe, String sonderausstattung) {
        this.hersteller = hersteller;
        this.antriebsart = antriebsart;
        this.motorleistung = motorleistung;
        this.farbe = farbe;
        this.sonderausstattung = sonderausstattung;
    }

    public String getHersteller() {
        return hersteller;
    }

    public String getAntriebsart() {
        return antriebsart;
    }

    public int getMotorleistung() {
        return motorleistung;
    }

    public String getFarbe() {
        return farbe;
    }

    public String getSonderausstattung() {
        return sonderausstattung;
    }
}

class Autohaus {
    private String name;
    private String besitzer;
    private String adresse;
    private String automarke;
    private List<Auto> autos;

    public Autohaus(String name, String besitzer, String adresse, String automarke) {
        this.name = name;
        this.besitzer = besitzer;
        this.adresse = adresse;
        this.automarke = automarke;
        this.autos = new ArrayList<>();
    }

    public void addAuto(Auto auto) {
        autos.add(auto);
    }

    public void printAutohaus() {
        System.out.println("Autohaus: " + name);
        System.out.println("Besitzer: " + besitzer);
        System.out.println("Adresse: " + adresse);
        System.out.println("Automarke: " + automarke);
        System.out.println("Autos auf der Verkaufsfläche:");
        for (Auto auto : autos) {
            System.out.println("------------------------");
            System.out.println("Hersteller: " + auto.getHersteller());
            System.out.println("Antriebsart: " + auto.getAntriebsart());
            System.out.println("Motorleistung: " + auto.getMotorleistung());
            System.out.println("Farbe: " + auto.getFarbe());
            System.out.println("Sonderausstattung: " + auto.getSonderausstattung());
        }
    }
}

public class AutohausMain {
    public static void main(String[] args) {
        Autohaus autohaus = new Autohaus("Mein Autohaus", "Max Mustermann", "Musterstraße 123", "Mustermarke");

        Auto auto1 = new Auto("Audi", "Diesel", 150, "Blau", "Mikrowelle");
        Auto auto2 = new Auto("BMW", "E", 200, "Rot", "GPS");
        Auto auto3 = new Auto("Porsche", "Hybrid", 180, "Grün", "Duftbaum");

        autohaus.addAuto(auto1);
        autohaus.addAuto(auto2);
        autohaus.addAuto(auto3);

        autohaus.printAutohaus();
    }
}