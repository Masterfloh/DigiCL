abstract class Pizza {
    private String[] zutaten;

    public Pizza(String[] zutaten) {
        this.zutaten = zutaten;
    }

    public String[] getZutaten() {
        return zutaten;
    }

    public abstract double getPreis();
}

class PizzaNapolitana extends Pizza {
    private double preis;

    public PizzaNapolitana() {
        super(new String[]{"Tomaten", "Mozzarella", "Olivenöl", "Knoblauch"});
        this.preis = 9.99;
    }

    @Override
    public double getPreis() {
        return preis;
    }
}

class PizzaMargherita extends Pizza {
    private String groesse;
    private double preis;

    public PizzaMargherita(String groesse) {
        super(new String[]{"Tomaten", "Mozzarella", "Basilikum", "Olivenöl"});
        this.groesse = groesse;
        setPreis(groesse);
    }

    private void setPreis(String groesse) {
        if (groesse.equals("klein")) {
            preis = 7.99;
        } else if (groesse.equals("mittel")) {
            preis = 9.99;
        } else if (groesse.equals("gross")) {
            preis = 11.99;
        } else {
            preis = 0.0;
        }
    }

    @Override
    public double getPreis() {
        return preis;
    }

    public String getGroesse() {
        return groesse;
    }
}

public class PizzaMain {
    public static void main(String[] args) {
        Pizza[] pizzen = new Pizza[2];
        pizzen[0] = new PizzaNapolitana();
        pizzen[1] = new PizzaMargherita("mittel");

        double gesamtPreis = 0.0;
        for (Pizza pizza : pizzen) {
            gesamtPreis += pizza.getPreis();
        }

        System.out.println("Gesamtpreis der Pizzas: " + gesamtPreis);
    }
}
