import Vue from "vue";
import Router from "vue-router";
import Main from "./views/MainView.vue";
import GetStarted from "./views/ToDoApp.vue";
import { ROUTER_BASE } from "@/Constants";
import ProjectTwo from "./views/CookieClicker.vue";
import CodeLibrary from "./views/CodeLibrary.vue";
import EasterEgg from "./views/EasterEgg.vue";
import BPM from "./views/BPM.vue";
import DM from "./views/DM.vue";

Vue.use(Router);

/*
 * Preventing "NavigationDuplicated" errors in console in Vue-router >= 3.1.0
 * https://github.com/vuejs/vue-router/issues/2881#issuecomment-520554378
 * */
/* eslint-disable @typescript-eslint/no-explicit-any */
const routerMethods = ["push", "replace"];
routerMethods.forEach((method: string) => {
    const originalCall = (Router.prototype as any)[method];
    (Router.prototype as any)[method] = function (
        location: any,
        onResolve: any,
        onReject: any
    ): Promise<any> {
        if (onResolve || onReject) {
            return originalCall.call(this, location, onResolve, onReject);
        }
        return originalCall.call(this, location).catch((err: any) => err);
    };
});
/* eslint-enable @typescript-eslint/no-explicit-any */

export default new Router({
    base: ROUTER_BASE,
    routes: [
        {
            path: "/",
            name: "home",
            component: Main,
            meta: {},
        },
        {
            path: "/todoapp",
            name: "todo-app",
            component: GetStarted,
        },
        {
            path: "/cookieclicker",
            name: "cookieclicker",
            component: ProjectTwo,
        },
        {
            path: "/codelibrary",
            name: "codelibrary",
            component: CodeLibrary,
        },
        {
            path: "/EasterEgg",
            name: "EasterEgg",
            component: EasterEgg,
        },
        {
            path: "/businessprocessmodels",
            name: "bpm",
            component: BPM,
        },
        {
            path: "/datamodels",
            name: "dm",
            component: DM,
        },
        { path: "*", redirect: "/" }, //Fallback 2
    ],
});
