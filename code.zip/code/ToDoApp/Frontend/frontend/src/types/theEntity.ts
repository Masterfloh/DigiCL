interface TheEntity {
    userinput: string;
    checkbox: boolean;
    id: string;
}
export default TheEntity;