export default class HealthState {
    status: string;

    constructor(status: string) {
        this.status = status;
    }
}
