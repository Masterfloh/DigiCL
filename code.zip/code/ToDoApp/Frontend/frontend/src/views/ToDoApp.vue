<template>
    <v-container fluid>
        <v-btn @click="addNewGoal">New Goal</v-btn>

        <v-btn @click="deleteAll()">Delete All</v-btn>
        <v-text-field
            v-model="name"
            placeholder="Name"
        ></v-text-field>
        <div
            v-for="entity in goals"
            :key="entity.id"
        >
            <input
                v-model="entity.checkbox"
                type="checkbox"
                @input="checkEntity(entity)"
            />
            <label>
                <input
                    v-model="entity.userinput"
                    placeholder=" Goal"
                    size="110"
                    @input="changeEntity(entity)"
                />
            </label>
            <button @click="deleteGoal(entity.id)">Delete</button>
        </div>
    </v-container>
</template>

<script setup lang="ts">
import { ref, Ref, onMounted } from "vue";
import FetchUtils from "@/api/FetchUtils";
import theEntity from "@/types/theEntity";

const name = ref("");
const goals: Ref<theEntity[]> = ref([]);

onMounted(() => {
    getEntities();
    return;
});

function checkEntity(entity: theEntity) {
    entity.checkbox = !entity.checkbox;
    fetch(
        `http://localhost:8082/api/todoappjakob-backend-service/theEntities/${entity.id}`,
        FetchUtils.getPUTConfig({ ...entity })
    );
}
function changeEntity(entity: theEntity) {
    fetch(
        `http://localhost:8082/api/todoappjakob-backend-service/theEntities/${entity.id}`,
        FetchUtils.getPUTConfig({ ...entity })
    );
}
function getEntities() {
    fetch(
        "http://localhost:8082/api/todoappjakob-backend-service/theEntities",
        FetchUtils.getGETConfig()
    ).then((r) => {
        r.json().then((b) => {
            goals.value = b._embedded.theEntities;
        });
    });
}

const deleteGoal = (index: string) => {
    fetch(
        `http://localhost:8082/api/todoappjakob-backend-service/theEntities/${index}`,
        {
            method: "DELETE",
        }
    ).then(() => getEntities());
};

const deleteAll = () => {
    goals.value.forEach((e) => {
        deleteGoal(e.id);
    });
};

function addNewGoal() {
    const newGoal = { checkbox: false, userinput: "" };
    fetch(
        "http://localhost:8082/api/todoappjakob-backend-service/theEntities",
        FetchUtils.getPOSTConfig({ ...newGoal })
    ).then(() => getEntities());
}
</script>
