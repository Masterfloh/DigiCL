<template>
    <v-container>
        <v-row class="text-center">
            <v-col cols="12">
                <v-img
                    :src="require('../assets/besserelogo.jpg')"
                    class="my-3"
                    contain
                    height="200"
                    style="filter: invert(100%)"
                />
            </v-col>

            <v-col class="mb-4">
                <h1 class="text-h3 font-weight-bold mb-3">
                    Welcome to the Digital Code Library
                </h1>
                <p>
                    The API-Gateway is currently
                    <span :class="status">{{ status }}</span>
                </p>
            </v-col>
        </v-row>
    </v-container>
</template>

<script setup lang="ts">
import HealthService from "@/api/HealthService";
import HealthState from "@/types/HealthState";
import { useSnackbarStore } from "@/stores/snackbar";
import { onMounted, ref } from "vue";

const snackbarStore = useSnackbarStore();
const status = ref("DOWN");

onMounted(() => {
    HealthService.checkHealth()
        .then((content: HealthState) => (status.value = content.status))
        .catch((error) => {
            snackbarStore.showMessage(error);
        });
});
</script>

<style scoped>
.UP {
    color: limegreen;
}

.DOWN {
    color: lightcoral;
}

h1 {
    color: #fcba03;
}
</style>
