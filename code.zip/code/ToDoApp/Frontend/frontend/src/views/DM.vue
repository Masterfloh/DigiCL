<template>
    <div>
        <br />
        Ich bin Besitzer einer Fahrradwerkstatt und möchte Kundenaufträge
        verwalten. Dazu wird das Abgabedatum erfasst und das Datum bis wann die
        Reparatur abgeschlossen sein soll. Zu den Reparaturen werden manchmal
        auch Ersatzteile bestellt. Den Bestellfortschritt der Ersatzteile muss
        ich überprüfen könne. Die Aufträge möchte ich meinen Mitarbeitern
        zuweisen und den Fortschritt der Reparatur verfolgen können.

        <br />
        <br />
        <v-img
            lazy-src="src/assets/fahrradDM.png"
            max-height="900"
            max-width="600"
            src="src/assets/fahrradDM.png"
        ></v-img>
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />

        Ich bin Besitzer einer Fahrschule und möchte meine Fahrer und Fahrzeuge
        für Fahrstunden verplanen können, sodass ich immer weiß, wann ich einem
        Fahrschüler einen neuen Termin geben kann.
        <br />
        <br />
        <v-img
            lazy-src="src/assets/carDM.png"
            max-height="1920"
            max-width="1080"
            src="src/assets/carDM.png"
        ></v-img>
    </div>
</template>
<script setup lang="ts">
</script>