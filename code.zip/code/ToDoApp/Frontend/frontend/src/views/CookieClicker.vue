<template>
    <v-app>
        <v-container
            class="fill-height"
            fluid
        >
            <v-row
                align="center"
                justify="center"
                class="h-100"
            >
                <v-col
                    cols="12"
                    md="6"
                    class="text-center"
                >
                    <h1 class="mt-5 mb-4">Cookie Clicker</h1>
                    <h2 class="mb-5">{{ message }}</h2>
                    <h2>Cookies: {{ cookies }}</h2>
                    <v-btn
                        color="primary"
                        dark
                        class="mt-5"
                        @click="clickCookie"
                    >
                        Click me!
                    </v-btn>
                </v-col>
                <v-col
                    cols="12"
                    md="6"
                    class="text-center"
                >
                    <h2>Cookies per Second: {{ cookiesPerSecond }}</h2>
                    <v-card class="mt-5">
                        <v-list>
                            <v-list-item
                                v-for="(upgrade, index) in upgrades"
                                :key="index"
                            >
                                <v-list-item-content>
                                    <v-list-item-title>{{
                                        upgrade.name
                                    }}</v-list-item-title>
                                    <v-list-item-subtitle
                                        >{{
                                            upgrade.price
                                        }}
                                        cookies</v-list-item-subtitle
                                    >
                                </v-list-item-content>
                                <v-list-item-action>
                                    <v-btn
                                        :disabled="upgrade.price > cookies"
                                        color="success"
                                        @click="buyUpgrade(upgrade)"
                                    >
                                        Buy
                                    </v-btn>
                                </v-list-item-action>
                            </v-list-item>
                        </v-list>
                    </v-card>
                </v-col>
            </v-row>
            <v-btn
                fab
                small
                color="error"
                class="clear-storage"
                @click="clearStorage"
            >
                <v-tooltip bottom>
                    <template #activator="{ on }">
                        <v-icon v-on="on">mdi-delete</v-icon>
                    </template>
                    <span>Delete local game storage</span>
                </v-tooltip>
            </v-btn>
        </v-container>
    </v-app>
</template>

<script>
const DEFAULT_UPGRADES = [
    { name: "Test", price: 1, cps: 2147483647 },
    { name: "Cursor", price: 15, cps: 10 },
    { name: "Grandma", price: 100, cps: 50 },
    { name: "Farm", price: 1100, cps: 100 },
    { name: "Mine", price: 12000, cps: 500 },
    { name: "Factory", price: 130000, cps: 2600 },
    { name: "Bank", price: 1400000, cps: 14000 },
    { name: "Temple", price: 20000000, cps: 78000 },
];

export default {
    data() {
        return {
            cookies: 0,
            cookiesPerSecond: 0,
            upgrades: [...DEFAULT_UPGRADES],
            intervalid: 0,
        };
    },

    computed: {
        message() {
            const totalCookies = this.cookies;
            if (totalCookies < 5)
                return "You feel like making cookies. But nobody wants to eat your cookies.";
            if (totalCookies < 50)
                return "Your first batch goes in the trash. The neighborhood raccoon barely touches it.";
            if (totalCookies < 100)
                return "Your family accepts to try some of your cookies.";
            if (totalCookies < 500)
                return "Your cookies are popular in the neighborhood.";
            if (totalCookies < 1000)
                return "People are starting to talk about your cookies.";
            if (totalCookies < 5000)
                return "Your cookies are talked about for miles around.";
            if (totalCookies < 10000)
                return "Your cookies are renowned in the whole town!";
            if (totalCookies < 50000)
                return "Your cookies bring all the boys to the yard.";
            if (totalCookies < 100000)
                return "Your cookies now have their own website!";
            if (totalCookies < 500000)
                return "Your cookies are worth a lot of money.";
            if (totalCookies < 1000000)
                return "Your cookies sell very well in distant countries.";
            if (totalCookies < 5000000)
                return "People come from very far away to get a taste of your cookies.";
            if (totalCookies < 10000000)
                return "Kings and queens from all over the world are enjoying your cookies.";
            if (totalCookies < 50000000)
                return "There are now museums dedicated to your cookies.";
            if (totalCookies < 100000000)
                return "A national day has been created in honor of your cookies.";
            if (totalCookies < 500000000)
                return "Your cookies have been named a part of the world wonders.";
            if (totalCookies < 1000000000)
                return "History books now include a whole chapter about your cookies.";
            if (totalCookies < 5000000000)
                return "Your cookies have been placed under government surveillance.";
            if (totalCookies < 10000000000)
                return "The whole planet is enjoying your cookies!";
            if (totalCookies < 50000000000)
                return "Strange creatures from neighboring planets wish to try your cookies.";
            if (totalCookies < 100000000000)
                return "Elder gods from the whole cosmos have awoken to taste your cookies.";
            if (totalCookies < 500000000000)
                return "Beings from other dimensions lapse into existence just to get a taste of your cookies.";
            if (totalCookies < 1000000000000)
                return "Your cookies have achieved sentience.";
            if (totalCookies < 5000000000000)
                return "The universe has now turned into cookie dough, to the molecular level.";
            if (totalCookies < 10000000000000)
                return "Your cookies are rewriting the fundamental laws of the universe.";
            return "It's time to stop playing";
        },
    },
    mounted() {
        this.loadGame();
        this.intervalid = setInterval(() => {
            this.cookies += this.cookiesPerSecond;
            this.saveGame();
        }, 1000);
    },

    beforeDestroy() {
        window.clearInterval(this.intervalid);
    },

    methods: {
        clickCookie() {
            this.cookies++;
            this.saveGame();
        },
        buyUpgrade(upgrade) {
            if (this.cookies >= upgrade.price) {
                this.cookies -= upgrade.price;
                this.cookiesPerSecond += upgrade.cps;
                upgrade.price = Math.round(
                    upgrade.price *
                        1.15 **
                            (this.getBuildingCount(upgrade) -
                                this.getUpgradeCount(upgrade))
                );
                this.saveGame();
            }
        },
        getBuildingCount(upgrade) {
            return this.upgrades.filter((u) => u.name === upgrade.name).length;
        },
        getUpgradeCount(upgrade) {
            return this.upgrades.filter(
                (u) => u.name === upgrade.name && u.price > upgrade.price
            ).length;
        },
        saveGame() {
            localStorage.setItem(
                "cookieClickerGameData",
                JSON.stringify(this.$data)
            );
        },
        loadGame() {
            const savedGameData = localStorage.getItem("cookieClickerGameData");
            if (savedGameData) {
                const gameData = JSON.parse(savedGameData);
                Object.assign(this.$data, gameData);
            }
        },
        clearStorage() {
            localStorage.removeItem("cookieClickerGameData");
            location.reload();
        },
    },
};
</script>

<style>
body {
    background-color: #f5f5f5;
    margin: 0;
    padding: 0;
}

h1 {
    text-align: center;
    margin-top: 25px;
    color: #d32f2f;
}

h2 {
    text-align: center;
    font-size: 14px;
    margin-bottom: 20px;
    color: #616161;
}

.v-btn {
    margin: 10px;
}

.clear-storage {
    position: absolute;
    bottom: 40px;
    left: 20px;
    margin-bottom: 20px;
}

.clear-storage:hover {
    transform: scale(1.1);
    transition: transform 0.2s ease-in-out;
}
</style>

