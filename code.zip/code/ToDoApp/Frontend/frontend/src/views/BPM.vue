<template>
    <div>
        <br />
        Ich bin Besitzer einer Fahrradwerkstatt und möchte Kundenaufträge
        verwalten. Dazu wird das Abgabedatum erfasst und das Datum bis wann die
        Reparatur abgeschlossen sein soll. Zu den Reparaturen werden manchmal
        auch Ersatzteile bestellt. Den Bestellfortschritt der Ersatzteile muss
        ich überprüfen könne. Die Aufträge möchte ich meinen Mitarbeitern
        zuweisen und den Fortschritt der Reparatur verfolgen können.

        <br />
        <br />
        <v-img
            lazy-src="src/assets/bikeBPM.png"
            max-height="3000"
            max-width="2000"
            src="src/assets/bikeBPM.png"
        ></v-img>
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />

        Ich bin Besitzer eines Supermarktes und muss über die Angebotenen Waren
        und Mengen der Waren Bescheid wissen, um rechtzeitig neue Waren
        bestellen zu können.
        <br />
        <br />
        <v-img
            lazy-src="src/assets/shopBPM.png"
            max-height="3000"
            max-width="2000"
            src="src/assets/shopBPM.png"
        ></v-img>
    </div>
</template>
<script setup lang="ts">
</script>