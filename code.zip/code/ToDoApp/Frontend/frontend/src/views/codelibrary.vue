<template>
    <div class="text-center">
        <v-menu offset-y>
            <template #activator="{ on, attrs }">
                <v-btn
                    color="primary"
                    dark
                    v-bind="attrs"
                    v-on="on"
                >
                    Code Library
                </v-btn>
            </template>
            <v-list>
                <v-list-item
                    v-for="(item, index) in items"
                    :key="index"
                    target="_blank"
                    @click="redirectToLink(item.link)"
                >
                    <v-list-item-title>{{ item.title }}</v-list-item-title>
                </v-list-item>
            </v-list>
        </v-menu>
    </div>
</template>

<script>
export default {
    data: () => ({
        items: [
            {
                title: "Median.java",
                link: "https://google.com",
            },
            {
                title: "Autohaus.java",
                link: "https://google.com",
            },
            {
                title: "Flugzeug.java",
                link: "https://google.com",
            },
            {
                title: "Monoton.java",
                link: "https://google.com",
            },
            {
                title: "PizzaPreise.java",
                link: "https://google.com",
            },
            {
                title: "Polymorphismus.java",
                link: "https://google.com",
            },
        ],
    }),
    methods: {
        redirectToLink(link) {
            window.location.href = link;
        },
    },
};
</script>
