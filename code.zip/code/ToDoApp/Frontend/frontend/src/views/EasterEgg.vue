<template>
    <div>
        <v-img
            lazy-src="src/assets/easteregg.png"
            max-height="1600"
            max-width="900"
            src="src/assets/easteregg.png"
        ></v-img>
    </div>
</template>
<script setup lang="ts">
</script>