module.exports = {
    transpileDependencies: ['vuetify']
};