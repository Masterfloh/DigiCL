# RefArch-Kickstarter-GUI

```
npm install
```

```
npm run serve
```

```
npm run build
```

```
npm run test
```

```
npm run lint
```

See [Configuration Reference](https://cli.vuejs.org/config/).
